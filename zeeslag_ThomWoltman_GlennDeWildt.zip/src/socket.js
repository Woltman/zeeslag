(function(zeeslag) {
    function Socket(token){
        this.token = token;
    }
    
})(window.zeeslag = window.zeeslag || {});