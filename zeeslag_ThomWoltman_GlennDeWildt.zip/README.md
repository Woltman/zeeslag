# Zeeslag

## To run:
- install NodeJS LTS versie
- `npm install` in the root of the repository
- after that run `npm run dev`